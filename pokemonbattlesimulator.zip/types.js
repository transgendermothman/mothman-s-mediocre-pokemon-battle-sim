let typeBonus = 0;

// un