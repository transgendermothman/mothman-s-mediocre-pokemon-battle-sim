var pokeNum = 0;

const pokemon = [
    
]