const pokedex = [
        {
            name: "Bulbasaur",
            dex: 1,
            type: ["Grass"],
            ability: ["Overgrow"],
            stats: [45,49,49,65,65,45],
            moves: ["Tackle", "Magical Leaf"],
        },
        {
            name: "Charmander",
            dex: 4,
            type: ["Fire"],
            ability: ["Blaze"],
            stats: [39,52,43,60,50,65],
            moves: ["Scratch", "Ember"],
        },
        {
            name: "Squirtle",
            dex: 7,
            type: ["Water"],
            ability: ["Torrent"],
            stats: [44,48,65,50,64,43],
            moves: ["Tackle", "Bubble"],
        },
    ];